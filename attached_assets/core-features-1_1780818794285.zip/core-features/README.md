# core-features

Pure backend/engine module extracted from Echo Music.

## What's inside

| Package | Contents |
|---|---|
| `db/` | Room database, DAOs, all entity models |
| `models/` | MediaMetadata, queue models, player state |
| `playback/` | MusicService, PlayerConnection, ExoPlayer queues, DownloadUtil |
| `spotify/` | Spotify API client, auth, mapper, all Spotify models |
| `spotifyimport/` | Spotify → local library import logic + ViewModel |
| `lyrics/` | All lyrics providers (KuGou, LrcLib, YouTube, BetterLyrics, etc.) |
| `localmedia/` | Local song scanner |
| `recognition/` | Shazam/music recognition engine |
| `listentogether/` | Real-time listen-together session manager |
| `api/` | DeepL, Mistral, OpenRouter API services |
| `eq/` | Parametric EQ engine + audio processor |
| `drive/` | Google Drive sync manager |
| `utils/` | Download, cipher, poToken, SABR, network utils |
| `extensions/` | Kotlin extension functions (no UI) |
| `constants/` | All preference keys, dimensions |
| `viewmodels/` | All ViewModels (depend on backend, not on UI) |
| `di/` | Hilt modules |

## Standalone library modules (also included)

`innertube`, `jiosaavn`, `kugou`, `lrclib`, `betterlyrics`,
`simpmusic`, `youlyplus`, `canvas`, `shazamkit`, `artistvideo`,
`applecanvas`, `echomusiccanvas`, `paxsenixlyrics`

## What was removed (UI-only)

- `ui/screens/` — all screen Composables
- `ui/component/` — all UI components
- `ui/player/` — player UI
- `ui/menu/` — context menus
- `ui/theme/` — theme/colors
- `ui/utils/` — UI helper functions
- `echomusic/` — updater, changelog UI
- `widget/` — home screen widget
- `ModifierExt.kt` — Compose modifier extensions
- `ComposeDebugUtils.kt`, `ShapesCurve.kt`, `IconUtils.kt`

## How to use in a new project

Add to `settings.gradle.kts`:
```kotlin
include(":core-features")
include(":innertube")
include(":jiosaavn")
// ... all other modules
```

Then in your app's `build.gradle.kts`:
```kotlin
implementation(project(":core-features"))
```
