plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.ksp)
    alias(libs.plugins.hilt)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.protobuf)
}

android {
    namespace = "iad1tya.echo.music.core"
    compileSdk = 36

    defaultConfig {
        minSdk = 24
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
    kotlinOptions {
        jvmTarget = "21"
    }

    room {
        schemaDirectory("$projectDir/schemas")
    }
}

// No UI dependencies — pure backend only
dependencies {
    // Kotlin coroutines
    implementation(libs.guava)
    implementation(libs.coroutines.guava)
    implementation(libs.concurrent.futures)

    // DataStore
    implementation(libs.datastore)

    // ViewModel (lifecycle, no Compose)
    implementation(libs.viewmodel)

    // Media3 playback engine
    implementation(libs.media3)
    implementation(libs.media3.session)
    implementation(libs.media3.hls)
    implementation(libs.media3.okhttp)

    // Room database
    implementation(libs.room.runtime)
    ksp(libs.room.compiler)
    implementation(libs.room.ktx)

    // Hilt DI
    implementation(libs.hilt)
    ksp(libs.hilt.compiler)

    // Networking
    implementation(libs.jsoup)
    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.ktor.client.content.negotiation)
    implementation(libs.ktor.serialization.json)

    // Protobuf
    implementation(libs.protobuf.javalite)
    implementation(libs.protobuf.kotlin.lite)

    // Apache commons
    implementation(libs.apache.lang3)

    // Logging
    implementation(libs.timber)

    // Background work
    implementation(libs.work.runtime.ktx)

    // Internal source modules
    implementation(project(":innertube"))
    implementation(project(":jiosaavn"))
    implementation(project(":kugou"))
    implementation(project(":lrclib"))
    implementation(project(":betterlyrics"))
    implementation(project(":simpmusic"))
    implementation(project(":youlyplus"))
    implementation(project(":canvas"))
    implementation(project(":shazamkit"))
    implementation(project(":artistvideo"))
    implementation(project(":applecanvas"))
    implementation(project(":echomusiccanvas"))
    implementation(project(":paxsenixlyrics"))
}
